package fr.zak.vue;

import java.awt.Color;

import javax.swing.JColorChooser;
import javax.swing.colorchooser.ColorSelectionModel;

public class PaletteCouleur extends JColorChooser {

	public PaletteCouleur() {
		super();
	}

	

}
