package fr.zak.vue;

import java.awt.Color;

import javax.swing.Icon;
import javax.swing.JLabel;

public class Label extends JLabel {
	/**
	 * un jlabel avec comme couleur par défaut le rouge
	 */
	public Label() {
		super();
		setForeground(Color.RED);
	}

	

}
