package fr.zak.vue;

public class Lanceur {
	
	FractalsFrame fractalsFrame;
	public Lanceur() {
		fractalsFrame=new FractalsFrame();
	}
	public static void main(String[] args) {
		Lanceur l=new Lanceur();
	}
}
