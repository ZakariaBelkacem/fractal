package fr.zak.vue;

import javax.swing.JOptionPane;

public class PanneauOption extends JOptionPane {
	public PanneauOption() {
		super();
		
	}

}
