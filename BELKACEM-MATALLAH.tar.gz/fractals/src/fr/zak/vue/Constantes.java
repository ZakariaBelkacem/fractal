package fr.zak.vue;
/**
 * 
 * @author zak
 *Les constantes des couleurs
 */
public interface Constantes {
	public final static String BLEU = "BLEU";
	public final static String RED = "ROUGE";
	public final static String GREEN = "VERT";
	public final static String BLACK = "NOIR";
	
}
